plugins {
  id("com.android.application")
  id("org.jetbrains.kotlin.android")
}

android {
  namespace = "com.ofeditor.app"
  compileSdk = 34

  defaultConfig {
    applicationId = "com.ofeditor.app"
    minSdk = 24
    targetSdk = 34
    versionCode = 1
    versionName = "1.0"

    ndk {
      abiFilters += listOf("armeabi-v7a", "arm64-v8a")
    }
  }

  buildTypes {
    release {
      isMinifyEnabled = false
      proguardFiles(
        getDefaultProguardFile("proguard-android-optimize.txt"),
        "proguard-rules.pro"
      )
    }
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
  }

  kotlinOptions {
    jvmTarget = "17"
  }
}

dependencies {
  implementation("androidx.core:core-ktx:1.13.1")
  implementation("androidx.appcompat:appcompat:1.7.0")
  implementation("com.google.android.material:material:1.12.0")
  val media3 = "1.4.1"
  implementation("androidx.media3:media3-exoplayer:$media3")
  implementation("androidx.media3:media3-ui:$media3")
  implementation("androidx.media3:media3-transformer:$media3")
  implementation("androidx.media3:media3-effect:$media3")
}