package com.ofeditor.app

import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Composition
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import java.io.File

@UnstableApi
class MainActivity : AppCompatActivity() {
  private var player: ExoPlayer? = null
  private var videoUri: Uri? = null
  private lateinit var status: TextView
  private lateinit var exportButton: Button

  private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
    if (uri != null) load(uri)
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)
    status = findViewById(R.id.statusText)
    exportButton = findViewById(R.id.exportButton)
    player = ExoPlayer.Builder(this).build().also {
      findViewById<PlayerView>(R.id.playerView).player = it
    }
    findViewById<Button>(R.id.pickVideoButton).setOnClickListener { picker.launch("video/*") }
    exportButton.setOnClickListener { export() }
  }

  private fun load(uri: Uri) {
    videoUri = uri
    player?.apply { setMediaItem(MediaItem.fromUri(uri)); prepare(); play() }
    status.text = "Video loaded. Set trim and rotation, then tap Export."
  }

  private fun num(id: Int): Double? = findViewById<EditText>(id).text.toString().toDoubleOrNull()

  private fun export() {
    val uri = videoUri ?: run { status.text = "Pick a video first."; return }
    val start = num(R.id.startField) ?: 0.0
    val end = num(R.id.endField)
    val rotation = (num(R.id.rotateField) ?: 0.0).toFloat()

    val clip = MediaItem.ClippingConfiguration.Builder().setStartPositionMs((start * 1000).toLong())
    if (end != null && end > start) clip.setEndPositionMs((end * 1000).toLong())
    val mediaItem = MediaItem.Builder().setUri(uri).setClippingConfiguration(clip.build()).build()

    val videoEffects = if (rotation != 0f)
      listOf(ScaleAndRotateTransformation.Builder().setRotationDegrees(rotation).build())
    else emptyList()
    val edited = EditedMediaItem.Builder(mediaItem)
      .setEffects(Effects(emptyList(), videoEffects)).build()

    val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
    val out = File(dir, "OFEditor_${System.currentTimeMillis()}.mp4")

    exportButton.isEnabled = false
    status.text = "Exporting..."
    Transformer.Builder(this)
      .addListener(object : Transformer.Listener {
        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
          exportButton.isEnabled = true
          status.text = "Saved: ${out.absolutePath}"
        }
        override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
          exportButton.isEnabled = true
          status.text = "Export failed: ${exportException.message}"
        }
      }).build()
      .start(edited, out.absolutePath)
  }

  override fun onDestroy() {
    player?.release()
    super.onDestroy()
  }
}
