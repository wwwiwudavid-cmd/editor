# OF Editor

This repository now includes:

1. A web app (`src/`) built with React + Vite + Tailwind.
2. An Android APK starter project (`android/`) for package `com.ofeditor.app`.

## Build APK On GitHub

1. Push this project to GitHub.
2. Open **Actions**.
3. Run workflow **Build APK** (or push to `main`/`master`).
4. Download artifact `of-editor-debug-apk` from the workflow run.

GitHub artifacts are ZIP downloads, so you get a zipped APK artifact directly.

## Android Project Path

- Android Gradle root: `android/`
- App module: `android/app/`
- Main package: `com.ofeditor.app`

## Optional Web Build On GitHub

Run workflow **Build Web App** to get artifact `of-editor-webapp-dist`.

## Android app status

The APK now has a working first feature set: pick a video, preview it, trim, rotate, and export an MP4
(Media3, works on 32-bit and 64-bit). Exports are saved in the app's Movies folder
(`Android/data/com.ofeditor.app/files/Movies`). Next steps: captions (whisper.cpp) and FFmpeg tools.
