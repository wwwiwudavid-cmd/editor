import { useMemo, useState } from "react";
import { motion } from "framer-motion";

type OperationKey =
  | "trim"
  | "speed"
  | "reverse"
  | "crop916"
  | "color"
  | "cleanVoice"
  | "removeSilence"
  | "toWav16k"
  | "gif";

type OperationInput = {
  input: string;
  output: string;
  start: number;
  end: number;
  speed: number;
  brightness: number;
  contrast: number;
  saturation: number;
};

const architectureChoices = [
  ["Package", "com.ofeditor.app", "Matches requested OF Editor identity"],
  ["ABIs", "armeabi-v7a + arm64-v8a", "Covers 32-bit and 64-bit ARM devices"],
  ["Min SDK / Target", "24 / 34", "Android 7 support with current store baseline"],
  ["Whisper model (64-bit)", "ggml-base.en-q5_1.bin", "Higher quality English captions"],
  ["Whisper model (32-bit)", "ggml-tiny.en-q5_1.bin", "Lower memory and CPU pressure"],
  ["Primary edits", "Media3 Transformer", "Hardware-friendly preview and transforms"],
  ["Advanced edits", "FFmpeg per ABI", "Reverse, denoise, GIF, and filter-based tasks"],
  ["Encoder policy", "h264_mediacodec -> mpeg4 fallback", "Stays LGPL-friendly"],
];

const buildOrder = [
  "Create Android project with Gradle, manifest, and ABI filters",
  "Ship Media3 player and file picker (GetContent contract)",
  "Add FFmpeg binaries and test trim command on both ABIs",
  "Integrate whisper.cpp JNI bridge and bundle English models",
  "Add caption burn-in export pipeline with Media3 overlays",
  "Expose user controls for trim, speed, crop, color, and audio cleanup",
];

const operationLabels: Record<OperationKey, string> = {
  trim: "Trim",
  speed: "Speed",
  reverse: "Reverse",
  crop916: "Crop to 9:16",
  color: "Color Adjust",
  cleanVoice: "Clean Voice",
  removeSilence: "Remove Silence",
  toWav16k: "Extract 16k WAV",
  gif: "GIF Export",
};

function commandForOperation(operation: OperationKey, values: OperationInput): string[] {
  switch (operation) {
    case "trim":
      return [
        "-i",
        values.input,
        "-ss",
        String(values.start),
        "-to",
        String(values.end),
        "-c:v",
        "h264_mediacodec",
        "-b:v",
        "8M",
        "-c:a",
        "aac",
        values.output,
      ];
    case "speed":
      return [
        "-i",
        values.input,
        "-filter_complex",
        `[0:v]setpts=${1 / values.speed}*PTS[v];[0:a]atempo=${values.speed}[a]`,
        "-map",
        "[v]",
        "-map",
        "[a]",
        "-c:v",
        "h264_mediacodec",
        "-b:v",
        "8M",
        values.output,
      ];
    case "reverse":
      return [
        "-i",
        values.input,
        "-vf",
        "reverse",
        "-af",
        "areverse",
        "-c:v",
        "h264_mediacodec",
        "-b:v",
        "8M",
        values.output,
      ];
    case "crop916":
      return [
        "-i",
        values.input,
        "-vf",
        "crop=ih*9/16:ih,scale=1080:1920",
        "-c:v",
        "h264_mediacodec",
        "-b:v",
        "8M",
        values.output,
      ];
    case "color":
      return [
        "-i",
        values.input,
        "-vf",
        `eq=brightness=${values.brightness}:contrast=${values.contrast}:saturation=${values.saturation}`,
        "-c:v",
        "h264_mediacodec",
        "-b:v",
        "8M",
        values.output,
      ];
    case "cleanVoice":
      return [
        "-i",
        values.input,
        "-af",
        "highpass=f=80,afftdn=nf=-25,loudnorm",
        "-c:v",
        "copy",
        values.output,
      ];
    case "removeSilence":
      return [
        "-i",
        values.input,
        "-af",
        "silenceremove=stop_periods=-1:stop_duration=0.6:stop_threshold=-35dB",
        values.output,
      ];
    case "toWav16k":
      return ["-i", values.input, "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", values.output];
    case "gif":
      return ["-i", values.input, "-vf", "fps=12,scale=480:-1", values.output];
    default:
      return [];
  }
}

export default function App() {
  const [operation, setOperation] = useState<OperationKey>("trim");
  const [checkedSteps, setCheckedSteps] = useState<number[]>([]);
  const [values, setValues] = useState<OperationInput>({
    input: "/sdcard/DCIM/input.mp4",
    output: "/sdcard/Movies/ofeditor/output.mp4",
    start: 0,
    end: 12,
    speed: 1.25,
    brightness: 0.02,
    contrast: 1.1,
    saturation: 1.05,
  });

  const args = useMemo(() => commandForOperation(operation, values), [operation, values]);

  const fallbackArgs = useMemo(() => {
    const copied = [...args];
    const encoderIndex = copied.indexOf("h264_mediacodec");
    if (encoderIndex < 0) return [];
    copied[encoderIndex] = "mpeg4";
    const bitrateIndex = copied.indexOf("-b:v");
    if (bitrateIndex >= 0) {
      copied[bitrateIndex] = "-q:v";
      copied[bitrateIndex + 1] = "3";
    }
    return copied;
  }, [args]);

  const progress = Math.round((checkedSteps.length / buildOrder.length) * 100);

  return (
    <main className="bg-zinc-950 text-zinc-100">
      <section className="relative min-h-screen overflow-hidden">
        <motion.img
          initial={{ scale: 1.15, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1.1, ease: "easeOut" }}
          src="/images/of-editor-hero.jpg"
          alt="Android phone running OF Editor"
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-black/50" />
        <div className="relative mx-auto flex min-h-screen w-full max-w-6xl items-center px-6 py-24 md:px-10">
          <div className="max-w-2xl space-y-6">
            <motion.p
              initial={{ y: 18, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.2, duration: 0.6 }}
              className="text-lg font-medium tracking-[0.28em] text-zinc-200"
            >
              OF EDITOR
            </motion.p>
            <motion.h1
              initial={{ y: 30, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.3, duration: 0.7 }}
              className="text-4xl leading-tight font-semibold text-white md:text-6xl"
            >
              Offline Android video editing, 32-bit and 64-bit ready.
            </motion.h1>
            <motion.p
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.45, duration: 0.7 }}
              className="max-w-xl text-base text-zinc-100/90 md:text-lg"
            >
              This starter app maps your exact stack: Media3 for core edits, FFmpeg for advanced ops, and whisper.cpp for
              English captions with ABI-aware model selection.
            </motion.p>
            <motion.div
              initial={{ y: 16, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.6, duration: 0.6 }}
              className="flex flex-wrap gap-3"
            >
              <a href="#lab" className="bg-white px-5 py-2.5 text-sm font-semibold text-zinc-900 transition hover:bg-zinc-200">
                Open Command Lab
              </a>
              <a href="#build-order" className="border border-zinc-300/60 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-white/10">
                Track Build Order
              </a>
            </motion.div>
          </div>
        </div>
      </section>

      <section className="mx-auto w-full max-w-6xl px-6 py-20 md:px-10">
        <h2 className="text-2xl font-semibold text-white">Architecture choices</h2>
        <p className="mt-2 max-w-3xl text-zinc-300">The app skeleton below is optimized for offline shipping, bilingual-free English captioning, and LGPL-safe exports.</p>
        <div className="mt-8 overflow-x-auto border-y border-zinc-800">
          <table className="w-full min-w-[700px] border-collapse text-left text-sm">
            <thead>
              <tr className="border-b border-zinc-800 text-zinc-400">
                <th className="py-3 pr-4 font-medium">Topic</th>
                <th className="py-3 pr-4 font-medium">Choice</th>
                <th className="py-3 font-medium">Why</th>
              </tr>
            </thead>
            <tbody>
              {architectureChoices.map(([topic, choice, why], index) => (
                <motion.tr
                  key={topic}
                  initial={{ opacity: 0, y: 12 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.4 }}
                  transition={{ duration: 0.35, delay: index * 0.03 }}
                  className="border-b border-zinc-900/80"
                >
                  <td className="py-4 pr-4 text-zinc-100">{topic}</td>
                  <td className="py-4 pr-4 text-zinc-300">{choice}</td>
                  <td className="py-4 text-zinc-400">{why}</td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <section id="lab" className="mx-auto w-full max-w-6xl px-6 py-20 md:px-10">
        <h2 className="text-2xl font-semibold text-white">FFmpeg command lab</h2>
        <p className="mt-2 max-w-3xl text-zinc-300">Generate command args exactly like your Android EditOps. Switch operations and copy the generated command into your Kotlin runner tests.</p>

        <div className="mt-8 space-y-8 border border-zinc-800 bg-zinc-900/40 p-5 md:p-7">
          <div className="grid gap-4 md:grid-cols-2">
            <label className="space-y-2 text-sm">
              <span className="text-zinc-300">Operation</span>
              <select
                value={operation}
                onChange={(event) => setOperation(event.target.value as OperationKey)}
                className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-zinc-100 focus:border-zinc-500 focus:outline-none"
              >
                {Object.entries(operationLabels).map(([value, label]) => (
                  <option key={value} value={value}>
                    {label}
                  </option>
                ))}
              </select>
            </label>
            <label className="space-y-2 text-sm">
              <span className="text-zinc-300">Input file</span>
              <input
                value={values.input}
                onChange={(event) => setValues((current) => ({ ...current, input: event.target.value }))}
                className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-zinc-100 focus:border-zinc-500 focus:outline-none"
              />
            </label>
            <label className="space-y-2 text-sm md:col-span-2">
              <span className="text-zinc-300">Output file</span>
              <input
                value={values.output}
                onChange={(event) => setValues((current) => ({ ...current, output: event.target.value }))}
                className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-zinc-100 focus:border-zinc-500 focus:outline-none"
              />
            </label>

            {operation === "trim" && (
              <>
                <label className="space-y-2 text-sm">
                  <span className="text-zinc-300">Start second</span>
                  <input
                    type="number"
                    value={values.start}
                    onChange={(event) => setValues((current) => ({ ...current, start: Number(event.target.value) }))}
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-zinc-100 focus:border-zinc-500 focus:outline-none"
                  />
                </label>
                <label className="space-y-2 text-sm">
                  <span className="text-zinc-300">End second</span>
                  <input
                    type="number"
                    value={values.end}
                    onChange={(event) => setValues((current) => ({ ...current, end: Number(event.target.value) }))}
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-zinc-100 focus:border-zinc-500 focus:outline-none"
                  />
                </label>
              </>
            )}

            {operation === "speed" && (
              <label className="space-y-2 text-sm md:col-span-2">
                <span className="text-zinc-300">Speed multiplier (0.5 to 2.0 for atempo)</span>
                <input
                  type="number"
                  min={0.5}
                  max={2}
                  step={0.05}
                  value={values.speed}
                  onChange={(event) => setValues((current) => ({ ...current, speed: Number(event.target.value) }))}
                  className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-zinc-100 focus:border-zinc-500 focus:outline-none"
                />
              </label>
            )}

            {operation === "color" && (
              <>
                <label className="space-y-2 text-sm">
                  <span className="text-zinc-300">Brightness</span>
                  <input
                    type="number"
                    step={0.01}
                    value={values.brightness}
                    onChange={(event) => setValues((current) => ({ ...current, brightness: Number(event.target.value) }))}
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-zinc-100 focus:border-zinc-500 focus:outline-none"
                  />
                </label>
                <label className="space-y-2 text-sm">
                  <span className="text-zinc-300">Contrast</span>
                  <input
                    type="number"
                    step={0.01}
                    value={values.contrast}
                    onChange={(event) => setValues((current) => ({ ...current, contrast: Number(event.target.value) }))}
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-zinc-100 focus:border-zinc-500 focus:outline-none"
                  />
                </label>
                <label className="space-y-2 text-sm md:col-span-2">
                  <span className="text-zinc-300">Saturation</span>
                  <input
                    type="number"
                    step={0.01}
                    value={values.saturation}
                    onChange={(event) => setValues((current) => ({ ...current, saturation: Number(event.target.value) }))}
                    className="w-full border border-zinc-700 bg-zinc-950 px-3 py-2 text-zinc-100 focus:border-zinc-500 focus:outline-none"
                  />
                </label>
              </>
            )}
          </div>

          <div className="space-y-3 text-sm">
            <p className="text-zinc-300">Primary command</p>
            <pre className="overflow-x-auto border border-zinc-800 bg-zinc-950 p-4 text-zinc-200">libffmpeg.so -y -hide_banner {args.join(" ")}</pre>
          </div>

          {fallbackArgs.length > 0 && (
            <div className="space-y-3 text-sm">
              <p className="text-zinc-300">Fallback command (if mediacodec fails)</p>
              <pre className="overflow-x-auto border border-zinc-800 bg-zinc-950 p-4 text-zinc-200">libffmpeg.so -y -hide_banner {fallbackArgs.join(" ")}</pre>
            </div>
          )}
        </div>
      </section>

      <section id="build-order" className="mx-auto w-full max-w-6xl px-6 py-20 md:px-10">
        <h2 className="text-2xl font-semibold text-white">Build order tracker</h2>
        <p className="mt-2 max-w-3xl text-zinc-300">Use this checklist while assembling the Android app. Progress is local to this session.</p>

        <div className="mt-6 h-2 w-full overflow-hidden bg-zinc-800">
          <motion.div
            animate={{ width: `${progress}%` }}
            transition={{ type: "spring", stiffness: 120, damping: 20 }}
            className="h-full bg-emerald-500"
          />
        </div>
        <p className="mt-2 text-sm text-zinc-400">{progress}% complete</p>

        <div className="mt-6 space-y-4 border-t border-zinc-800 pt-6">
          {buildOrder.map((step, index) => {
            const checked = checkedSteps.includes(index);
            return (
              <label key={step} className="flex items-start gap-3 text-zinc-200">
                <input
                  type="checkbox"
                  checked={checked}
                  onChange={(event) => {
                    setCheckedSteps((current) => {
                      if (event.target.checked) return [...current, index];
                      return current.filter((item) => item !== index);
                    });
                  }}
                  className="mt-1 h-4 w-4 border-zinc-600 bg-zinc-900 accent-emerald-500"
                />
                <span className={checked ? "text-zinc-500 line-through" : "text-zinc-200"}>{step}</span>
              </label>
            );
          })}
        </div>
      </section>
    </main>
  );
}
