# OF Editor

This repository now includes:

1. A web app (`src/`) built with React + Vite + Tailwind.
2. An Android APK starter project (`android/`) for package `com.ofeditor.app`.

## Build APK On GitHub

1. Push this project to GitHub.
2. Open **Actions**.
3. Run workflow **Build APK** (or push to `main`/`master`).
4. Download artifact `of-editor-debug-apk` from the workflow run.

GitHub artifacts are ZIP downloads, so you get a zipped APK artifact directly.

## Android Project Path

- Android Gradle root: `android/`
- App module: `android/app/`
- Main package: `com.ofeditor.app`

## Optional Web Build On GitHub

Run workflow **Build Web App** to get artifact `of-editor-webapp-dist`.

## Android app status (v4: Code to Video)

Paste or open JavaScript canvas code. Define `DURATION` (seconds), optionally `FPS`, and `function draw(t)`
using the globals `ctx`, `W`, `H`. The app previews it, then renders every frame and encodes an H.264 MP4
(MediaCodec, offline, 32-bit and 64-bit) saved to Movies/OF Editor.

v5: export now renders and encodes in parallel (JS keeps drawing while Kotlin encodes) and uses a lighter YUV conversion.

v6: export size aligned to 16 px (1080p -> 1088x1920) and encoder size check, fixes distorted 1080p.
