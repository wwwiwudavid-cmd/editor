package com.ofeditor.app

import android.content.ClipboardManager
import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Base64
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject
import java.io.File
import kotlin.math.ceil

/** OF Editor: turns JavaScript canvas code into an MP4. Everything runs offline on the phone. */
class MainActivity : AppCompatActivity() {
  private lateinit var web: WebView
  private lateinit var code: EditText
  private lateinit var status: TextView
  private lateinit var timeText: TextView
  private lateinit var playBtn: TextView
  private lateinit var exportBtn: TextView
  private lateinit var seek: SeekBar
  private val prefs by lazy { getSharedPreferences("ofcode", MODE_PRIVATE) }

  private var duration = 0.0
  private var fps = 30
  private var playing = false
  private var userSeeking = false
  private var pendingCode: String? = null
  private var formatIdx = 0                  // 0 = 9:16, 1 = 16:9, 2 = 1:1
  private var quality = 1080                 // short side in pixels

  // export state
  @Volatile private var exporting = false
  @Volatile private var cancel = false
  private var enc: MediaCodec? = null
  private var muxer: MediaMuxer? = null
  private var track = -1
  private var muxStarted = false
  private var total = 0
  private var expW = 0
  private var expH = 0
  private var outFile: File? = null

  private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { u ->
    if (u != null) try {
      val t = contentResolver.openInputStream(u)?.bufferedReader()?.use { it.readText() } ?: ""
      code.setText(t); runCode()
    } catch (e: Exception) { setStatus("Could not read the file: ${e.message}", true) }
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)
    web = findViewById(R.id.web); code = findViewById(R.id.code); status = findViewById(R.id.status)
    timeText = findViewById(R.id.timeText); playBtn = findViewById(R.id.playBtn)
    exportBtn = findViewById(R.id.exportBtn); seek = findViewById(R.id.seek)

    web.settings.javaScriptEnabled = true
    web.addJavascriptInterface(Bridge(), "Android")
    web.webViewClient = object : WebViewClient() {
      override fun onPageFinished(view: WebView, url: String) {
        val src = pendingCode ?: return
        pendingCode = null
        val (pw, ph) = sizeFor(360)
        view.evaluateJavascript("setSize($pw,$ph);loadCode(${JSONObject.quote(src)})", null)
      }
    }

    code.setText(prefs.getString("code", SAMPLE))
    code.addTextChangedListener(object : android.text.TextWatcher {
      override fun afterTextChanged(s: android.text.Editable?) { prefs.edit().putString("code", s.toString()).apply() }
      override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
      override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
    })

    findViewById<View>(R.id.runBtn).setOnClickListener { runCode() }
    findViewById<View>(R.id.sampleBtn).setOnClickListener { code.setText(SAMPLE); runCode() }
    findViewById<View>(R.id.openBtn).setOnClickListener { picker.launch("*/*") }
    findViewById<View>(R.id.pasteBtn).setOnClickListener {
      val cm = getSystemService(ClipboardManager::class.java)
      val t = cm?.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
      if (t.isNullOrBlank()) setStatus("Clipboard is empty", true) else { code.setText(t); runCode() }
    }
    playBtn.setOnClickListener {
      playing = !playing
      web.evaluateJavascript(if (playing) "play()" else "pause()", null)
      playBtn.text = if (playing) "⏸" else "▶"
    }
    seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
      override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
        if (fromUser) web.evaluateJavascript("pause();seek(${p / 100.0})", null)
      }
      override fun onStartTrackingTouch(s: SeekBar) { userSeeking = true; playing = false; playBtn.text = "▶" }
      override fun onStopTrackingTouch(s: SeekBar) { userSeeking = false }
    })
    findViewById<TextView>(R.id.fmtBtn).setOnClickListener { v ->
      val names = arrayOf("9:16 (vertical)", "16:9 (wide)", "1:1 (square)")
      AlertDialog.Builder(this).setTitle("Video shape").setItems(names) { _, i ->
        formatIdx = i; (v as TextView).text = arrayOf("9:16", "16:9", "1:1")[i] + " ▾"
        val (pw, ph) = sizeFor(360); web.evaluateJavascript("setSize($pw,$ph)", null)
      }.show()
    }
    findViewById<TextView>(R.id.resBtn).setOnClickListener { v ->
      AlertDialog.Builder(this).setTitle("Export quality").setItems(arrayOf("480p", "720p", "1080p")) { _, i ->
        quality = intArrayOf(480, 720, 1080)[i]; (v as TextView).text = "${quality}p ▾"
      }.show()
    }
    exportBtn.setOnClickListener {
      if (exporting) { cancel = true } else { startExport() }
    }
    runCode()
  }

  // ---------- preview ----------
  private fun sizeFor(short: Int): Pair<Int, Int> {
    val long = (short * 16 / 9) / 2 * 2
    return when (formatIdx) { 0 -> Pair(short, long); 1 -> Pair(long, short); else -> Pair(short, short) }
  }

  private fun runCode() {
    if (exporting) return
    pendingCode = code.text.toString()
    setStatus("Running...", false)
    playing = false; playBtn.text = "▶"
    web.loadUrl("file:///android_asset/runner.html")
  }

  private fun setStatus(m: String, err: Boolean) {
    status.text = m; status.setTextColor(if (err) 0xFFFF7A7A.toInt() else 0xFFC3C4CF.toInt())
  }

  private fun mmss(t: Double) = "%02d:%02d".format((t / 60).toInt(), (t % 60).toInt())

  inner class Bridge {
    @JavascriptInterface fun ready(d: Double, f: Double) = runOnUiThread {
      duration = d; fps = f.toInt().coerceIn(1, 60); seek.max = (d * 100).toInt()
      setStatus("OK: ${"%.1f".format(d)} s at $fps fps. Tap Export to make the video.", false)
      playing = true; playBtn.text = "⏸"; web.evaluateJavascript("play()", null)
    }
    @JavascriptInterface fun time(t: Double) = runOnUiThread {
      if (!userSeeking && !exporting) seek.progress = (t * 100).toInt()
      timeText.text = "${mmss(t)} / ${mmss(duration)}"
    }
    @JavascriptInterface fun error(m: String) = runOnUiThread {
      if (exporting) endExport(false, m) else { setStatus("Error: $m", true); playing = false; playBtn.text = "▶" }
    }
    @JavascriptInterface fun frame(i: Int, data: String) = onFrame(i, data)
  }

  // ---------- export (same save method as before: cache file -> Movies/OF Editor) ----------
  private fun startExport() {
    if (duration <= 0) { setStatus("Run your code first", true); return }
    val (w, h) = sizeFor(quality)
    total = ceil(duration * fps).toInt()
    expW = w; expH = h
    outFile = File(cacheDir, "OFCode_${System.currentTimeMillis()}.mp4")
    try {
      val f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
      f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
      f.setInteger(MediaFormat.KEY_BIT_RATE, (w * h * fps * 0.15).toInt().coerceIn(1_000_000, 20_000_000))
      f.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
      f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
      enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC).also {
        it.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); it.start()
      }
      muxer = MediaMuxer(outFile!!.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
      track = -1; muxStarted = false
    } catch (e: Exception) {
      releaseCodec(); setStatus("This phone cannot encode ${w}x$h. Try a lower quality.", true); return
    }
    exporting = true; cancel = false
    window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    playing = false; playBtn.text = "▶"
    exportBtn.text = "✕ 0%"; setStatus("Rendering $total frames. Keep the app open.", false)
    web.evaluateJavascript("pause();setSize($w,$h);renderFrame(0)", null)
  }

  private fun onFrame(i: Int, data: String) {
    if (!exporting) return
    try {
      if (cancel) { endExport(false, "Cancelled"); return }
      val bytes = Base64.decode(data.substring(data.indexOf(',') + 1), Base64.DEFAULT)
      val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: throw IllegalStateException("Frame decode failed")
      encodeFrame(bmp, i); bmp.recycle()
      val pct = (i + 1) * 100 / total
      runOnUiThread { exportBtn.text = "✕ $pct%" }
      if (i + 1 < total) runOnUiThread { web.evaluateJavascript("renderFrame(${i + 1})", null) }
      else endExport(true, "")
    } catch (e: Exception) { endExport(false, e.message ?: "Export failed") }
  }

  private fun encodeFrame(bmp: Bitmap, i: Int) {
    val e = enc ?: return
    var idx = e.dequeueInputBuffer(10_000)
    while (idx < 0) { drain(false); idx = e.dequeueInputBuffer(10_000) }
    val img = e.getInputImage(idx) ?: throw IllegalStateException("Encoder input not available")
    fillImage(img, bmp)
    e.queueInputBuffer(idx, 0, expW * expH * 3 / 2, i * 1_000_000L / fps, 0)
    drain(false)
  }

  private fun fillImage(img: Image, bmp: Bitmap) {
    val w = expW; val h = expH
    val px = IntArray(w * h); bmp.getPixels(px, 0, w, 0, 0, w, h)
    val yP = img.planes[0]; val uP = img.planes[1]; val vP = img.planes[2]
    val yb = yP.buffer; val ub = uP.buffer; val vb = vP.buffer
    val row = ByteArray(w)
    for (j in 0 until h) {
      for (i in 0 until w) {
        val p = px[j * w + i]
        val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
        row[i] = (((66 * r + 129 * g + 25 * b + 128) shr 8) + 16).coerceIn(0, 255).toByte()
      }
      yb.position(j * yP.rowStride); yb.put(row, 0, w)
    }
    for (j in 0 until h / 2) for (i in 0 until w / 2) {
      val p = px[(2 * j) * w + 2 * i]
      val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
      ub.put(j * uP.rowStride + i * uP.pixelStride, (((-38 * r - 74 * g + 112 * b + 128) shr 8) + 128).coerceIn(0, 255).toByte())
      vb.put(j * vP.rowStride + i * vP.pixelStride, (((112 * r - 94 * g - 18 * b + 128) shr 8) + 128).coerceIn(0, 255).toByte())
    }
  }

  private fun drain(end: Boolean) {
    val e = enc ?: return; val m = muxer ?: return
    val info = MediaCodec.BufferInfo()
    while (true) {
      val o = e.dequeueOutputBuffer(info, if (end) 10_000 else 0)
      if (o == MediaCodec.INFO_TRY_AGAIN_LATER) { if (!end) return else continue }
      if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { track = m.addTrack(e.outputFormat); m.start(); muxStarted = true; continue }
      if (o < 0) continue
      val buf = e.getOutputBuffer(o)
      if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
      if (info.size > 0 && muxStarted && buf != null) {
        buf.position(info.offset); buf.limit(info.offset + info.size)
        m.writeSampleData(track, buf, info)
      }
      e.releaseOutputBuffer(o, false)
      if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) return
    }
  }

  private fun releaseCodec() {
    try { enc?.stop() } catch (_: Exception) { }
    try { enc?.release() } catch (_: Exception) { }
    try { if (muxStarted) muxer?.stop() } catch (_: Exception) { }
    try { muxer?.release() } catch (_: Exception) { }
    enc = null; muxer = null; muxStarted = false
  }

  private fun endExport(ok: Boolean, msg: String) {
    if (!exporting) return
    exporting = false
    var good = ok
    var err = msg
    if (ok) try {
      val e = enc!!
      val idx = e.dequeueInputBuffer(1_000_000)
      if (idx >= 0) e.queueInputBuffer(idx, 0, 0, total * 1_000_000L / fps, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
      drain(true)
    } catch (x: Exception) { good = false; err = x.message ?: "Could not finish the video" }
    releaseCodec()
    val file = outFile
    runOnUiThread {
      window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
      exportBtn.text = "⬇ Export"
      if (good && file != null) {
        val m = saveToGallery(file); setStatus(m, false); Toast.makeText(this, m, Toast.LENGTH_LONG).show()
      } else { file?.delete(); setStatus("Export stopped: $err", true) }
      val (pw, ph) = sizeFor(360)
      web.evaluateJavascript("setSize($pw,$ph);seek(0)", null)
    }
  }

  private fun saveToGallery(f: File): String {
    if (Build.VERSION.SDK_INT >= 29) {
      val v = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, f.name)
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/OF Editor")
      }
      val dest = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
      if (dest != null) {
        contentResolver.openOutputStream(dest)?.use { o -> f.inputStream().use { it.copyTo(o) } }
        f.delete(); return "Saved to Movies/OF Editor"
      }
    }
    val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
    val dest = File(dir, f.name); f.copyTo(dest, true); f.delete()
    return "Saved: ${dest.absolutePath}"
  }

  override fun onDestroy() {
    cancel = true; exporting = false; releaseCodec(); web.destroy(); super.onDestroy()
  }

  companion object {
    const val SAMPLE = """var DURATION = 6;
function draw(t) {
  ctx.fillStyle = '#0b1020'; ctx.fillRect(0, 0, W, H);
  var r = W * .12, x = W / 2 + Math.sin(t * 2) * W * .3, y = H / 2 + Math.cos(t * 3) * H * .2;
  ctx.fillStyle = '#8b5cf6'; ctx.beginPath(); ctx.arc(x, y, r, 0, 7); ctx.fill();
  ctx.fillStyle = '#fff'; ctx.textAlign = 'center'; ctx.font = '800 ' + W * .09 + 'px sans-serif';
  ctx.fillText('OF Editor', W / 2, H * .12);
  ctx.fillText(t.toFixed(1) + ' s', W / 2, H * .9);
}"""
  }
}
