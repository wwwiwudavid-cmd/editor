package com.ofeditor.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/** CapCut-style timeline: fixed playhead, scrolling clip with thumbnails and trim handles. */
class TimelineView(c: Context, a: AttributeSet? = null) : View(c, a) {
  private val d = resources.displayMetrics.density
  private val p = Paint(Paint.ANTI_ALIAS_FLAG)
  private val ppm = 0.06f * d            // pixels per millisecond
  private var dur = 0L; private var pos = 0L; private var ts = 0L; private var te = 0L
  private var mode = 0; private var lastX = 0f
  private val rulerH get() = 26 * d
  var thumbs: List<Bitmap> = emptyList()
    set(v) { field = v; invalidate() }
  var onScrub: ((Long) -> Unit)? = null
  var onTrim: ((Long, Long, Boolean) -> Unit)? = null

  fun setDuration(v: Long) { dur = v; invalidate() }
  fun setTrim(s: Long, e: Long) { ts = s; te = e; invalidate() }
  fun setPos(v: Long) { pos = v; invalidate() }
  private fun x(ms: Long) = width / 2f + (ms - pos) * ppm

  override fun onDraw(cv: Canvas) {
    cv.drawColor(0xFF120D1C.toInt())
    if (dur <= 0) return
    p.textSize = 10 * d; p.textAlign = Paint.Align.CENTER; p.strokeWidth = 1.5f * d
    val halfMs = (width / 2f / ppm).toLong()
    val first = maxOf(0L, (pos - halfMs) / 1000)
    val last = minOf(dur / 1000, (pos + halfMs) / 1000 + 1)
    for (s in first..last) {
      val xx = x(s * 1000); val five = s % 5 == 0L
      p.style = Paint.Style.FILL; p.color = if (five) 0xFFE9DDFF.toInt() else 0x66E9DDFF
      cv.drawLine(xx, rulerH * (if (five) 0.5f else 0.7f), xx, rulerH * 0.9f, p)
      if (five) cv.drawText("%02d:%02d".format(s / 60, s % 60), xx, rulerH * 0.42f, p)
    }
    val top = rulerH + 8 * d; val bot = height - 8 * d
    val left = x(0); val right = x(dur)
    cv.save(); cv.clipRect(left, top, right, bot)
    if (thumbs.isEmpty()) { p.color = 0xFF3B2A63.toInt(); cv.drawRect(left, top, right, bot, p) }
    else {
      val w = (right - left) / thumbs.size
      thumbs.forEachIndexed { i, b -> cv.drawBitmap(b, null, RectF(left + i * w, top, left + (i + 1) * w, bot), null) }
    }
    p.color = 0xB3000000.toInt()
    cv.drawRect(left, top, x(ts), bot, p); cv.drawRect(x(te), top, right, bot, p)
    cv.restore()
    p.style = Paint.Style.STROKE; p.strokeWidth = 2 * d; p.color = 0xFFA855F7.toInt()
    cv.drawRect(x(ts), top, x(te), bot, p)
    p.style = Paint.Style.FILL
    cv.drawRoundRect(RectF(x(ts) - 10 * d, top, x(ts), bot), 4 * d, 4 * d, p)
    cv.drawRoundRect(RectF(x(te), top, x(te) + 10 * d, bot), 4 * d, 4 * d, p)
    p.color = 0xFFFFFFFF.toInt(); p.strokeWidth = 2 * d
    cv.drawLine(width / 2f, rulerH * 0.2f, width / 2f, height.toFloat(), p)
  }

  override fun onTouchEvent(e: MotionEvent): Boolean {
    if (dur <= 0) return true
    when (e.actionMasked) {
      MotionEvent.ACTION_DOWN -> {
        lastX = e.x; parent?.requestDisallowInterceptTouchEvent(true)
        mode = when {
          e.x in (x(ts) - 26 * d)..(x(ts) + 8 * d) -> 2
          e.x in (x(te) - 8 * d)..(x(te) + 26 * d) -> 3
          else -> 1
        }
      }
      MotionEvent.ACTION_MOVE -> {
        val dx = (e.x - lastX) / ppm; lastX = e.x
        when (mode) {
          1 -> { pos = (pos - dx).toLong().coerceIn(0L, dur); onScrub?.invoke(pos) }
          2 -> { ts = (ts + dx).toLong().coerceIn(0L, te - 500); onTrim?.invoke(ts, te, false) }
          3 -> { te = (te + dx).toLong().coerceIn(ts + 500, dur); onTrim?.invoke(ts, te, false) }
        }
        invalidate()
      }
      MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
        if (mode == 2 || mode == 3) onTrim?.invoke(ts, te, true)
        mode = 0
      }
    }
    return true
  }
}
