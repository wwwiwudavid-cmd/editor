package com.ofeditor.app

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.ChannelMixingAudioProcessor
import androidx.media3.common.audio.ChannelMixingMatrix
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.Crop
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.RgbFilter
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.effect.TextOverlay
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import com.google.common.collect.ImmutableList
import java.io.File

data class Edit(
  val ts: Long = 0, val te: Long = 0, val speed: Float = 1f, val vol: Float = 1f,
  val rot: Float = 0f, val flipH: Boolean = false, val flipV: Boolean = false,
  val bright: Float = 0f, val contrast: Float = 0f, val sat: Float = 0f,
  val bw: Boolean = false, val aspect: Float = 0f, val text: String = "", val res: Int = 1080
)

private class Tool(
  val icon: String, val label: String, val min: Float, val max: Float, val step: Float,
  val every: Int, val unitDp: Float, val get: (Edit) -> Float, val set: (Edit, Float) -> Edit,
  val fmt: (Float) -> String
)

@UnstableApi
class MainActivity : AppCompatActivity() {
  private lateinit var player: ExoPlayer
  private lateinit var timeline: TimelineView
  private lateinit var ruler: RulerView
  private lateinit var timeText: TextView
  private lateinit var playBtn: TextView
  private lateinit var exportBtn: TextView
  private lateinit var toolPanel: View
  private val h = Handler(Looper.getMainLooper())
  private var uri: Uri? = null
  private var edit = Edit()
  private val undo = ArrayDeque<Edit>()
  private val redo = ArrayDeque<Edit>()
  private var snap = Edit(); private var preTrim = Edit(); private var trimming = false
  private var vw = 0; private var vh = 0
  private var exporting = false
  private var activeTool: Tool? = null

  private val tools = listOf(
    Tool("⏩", "Speed", 0.2f, 4f, 0.1f, 10, 10f, { it.speed }, { e, v -> e.copy(speed = v) }, { "%.1fx".format(it) }),
    Tool("🔊", "Volume", 0f, 200f, 5f, 4, 6f, { it.vol * 100 }, { e, v -> e.copy(vol = v / 100) }, { "${it.toInt()}%" }),
    Tool("🔄", "Rotate", -180f, 180f, 1f, 10, 6f, { it.rot }, { e, v -> e.copy(rot = v) }, { "${it.toInt()}°" }),
    Tool("☀", "Brightness", -100f, 100f, 1f, 10, 5f, { it.bright * 100 }, { e, v -> e.copy(bright = v / 100) }, { "${it.toInt()}" }),
    Tool("◐", "Contrast", -100f, 100f, 1f, 10, 5f, { it.contrast * 100 }, { e, v -> e.copy(contrast = v / 100) }, { "${it.toInt()}" }),
    Tool("🎨", "Color", -100f, 100f, 1f, 10, 5f, { it.sat }, { e, v -> e.copy(sat = v) }, { "${it.toInt()}" })
  )

  private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) load(u) }
  private val applyRun = Runnable { applyEdit() }

  private val tick = object : Runnable {
    override fun run() {
      if (uri != null && edit.te > 0) {
        val p = player.currentPosition
        if (player.isPlaying && p >= edit.te - 40) player.seekTo(edit.ts)
        timeline.setPos(p)
        val s = edit.speed
        timeText.text = "${mmss(((p - edit.ts).coerceAtLeast(0) / s).toLong())} / ${mmss(((edit.te - edit.ts) / s).toLong())}"
      }
      h.postDelayed(this, 40)
    }
  }

  override fun onCreate(savedInstanceState: android.os.Bundle?) {
    super.onCreate(savedInstanceState)
    setContentView(R.layout.activity_main)
    timeline = findViewById(R.id.timeline); ruler = findViewById(R.id.ruler)
    timeText = findViewById(R.id.timeText); playBtn = findViewById(R.id.playBtn)
    exportBtn = findViewById(R.id.exportBtn); toolPanel = findViewById(R.id.toolPanel)

    player = ExoPlayer.Builder(this).build()
    findViewById<PlayerView>(R.id.playerView).player = player
    player.addListener(object : Player.Listener {
      override fun onVideoSizeChanged(v: VideoSize) { vw = v.width; vh = v.height; scheduleApply() }
      override fun onIsPlayingChanged(p: Boolean) { playBtn.text = if (p) "⏸" else "▶" }
      override fun onPlaybackStateChanged(st: Int) {
        if (st == Player.STATE_READY && edit.te == 0L && player.duration > 0) {
          edit = edit.copy(te = player.duration)
          timeline.setDuration(player.duration); timeline.setTrim(0, player.duration)
        }
      }
    })

    findViewById<View>(R.id.importBtn).setOnClickListener { picker.launch("video/*") }
    playBtn.setOnClickListener { if (needVideo()) togglePlay() }
    exportBtn.setOnClickListener { if (needVideo()) export() }
    findViewById<View>(R.id.undoBtn).setOnClickListener {
      undo.removeLastOrNull()?.let { redo.addLast(edit); edit = it; applyEdit() }
    }
    findViewById<View>(R.id.redoBtn).setOnClickListener {
      redo.removeLastOrNull()?.let { undo.addLast(edit); edit = it; applyEdit() }
    }
    findViewById<TextView>(R.id.resBtn).setOnClickListener { v ->
      val items = arrayOf("480p", "720p", "1080p")
      AlertDialog.Builder(this).setTitle("Export quality").setItems(items) { _, i ->
        val r = intArrayOf(480, 720, 1080)[i]
        commit { it.copy(res = r) }; (v as TextView).text = "${r}p ▾"
      }.show()
    }
    findViewById<View>(R.id.toolDone).setOnClickListener { closeTool() }
    findViewById<View>(R.id.toolReset).setOnClickListener {
      val t = activeTool ?: return@setOnClickListener
      val def = t.get(Edit()); ruler.setValue(def); edit = t.set(edit, if (t.label == "Volume") def else def)
      findViewById<TextView>(R.id.toolValue).text = t.fmt(def); scheduleApply()
    }
    timeline.onScrub = { ms -> player.pause(); player.seekTo(ms) }
    timeline.onTrim = { s, e, fin ->
      if (!trimming) { preTrim = edit; trimming = true }
      edit = edit.copy(ts = s, te = e)
      if (player.currentPosition !in s..e) player.seekTo(s)
      if (fin) { undo.addLast(preTrim); redo.clear(); trimming = false }
    }
    buildStrip()
    h.post(tick)
  }

  private fun buildStrip() {
    tools.take(3).forEach { t -> addBtn(t.icon, t.label) { openTool(t) } }
    addBtn("↔", "Flip H") { commit { it.copy(flipH = !it.flipH) } }
    addBtn("↕", "Flip V") { commit { it.copy(flipV = !it.flipV) } }
    addBtn("▭", "Crop") {
      val names = arrayOf("Original", "9:16", "1:1", "16:9", "4:5")
      val vals = floatArrayOf(0f, 9 / 16f, 1f, 16 / 9f, 0.8f)
      AlertDialog.Builder(this).setTitle("Aspect ratio").setItems(names) { _, i -> commit { it.copy(aspect = vals[i]) } }.show()
    }
    tools.drop(3).forEach { t -> addBtn(t.icon, t.label) { openTool(t) } }
    addBtn("⚫", "B&W") { commit { it.copy(bw = !it.bw) } }
    addBtn("T", "Text") {
      val input = EditText(this).apply { setText(edit.text); hint = "Type text (empty = remove)" }
      AlertDialog.Builder(this).setTitle("Add text").setView(input)
        .setPositiveButton("OK") { _, _ -> commit { it.copy(text = input.text.toString().trim()) } }
        .setNegativeButton("Cancel", null).show()
    }
    addBtn("♻", "Reset all") { commit { Edit(ts = 0, te = player.duration.coerceAtLeast(0)) } }
  }

  private fun addBtn(icon: String, label: String, onClick: () -> Unit) {
    val d = resources.displayMetrics.density
    val t = TextView(this).apply {
      text = "$icon\n$label"; gravity = Gravity.CENTER; textSize = 12f
      setTextColor(0xFFE9DDFF.toInt())
      setPadding((14 * d).toInt(), (8 * d).toInt(), (14 * d).toInt(), (8 * d).toInt())
      setOnClickListener { if (needVideo()) onClick() }
    }
    findViewById<LinearLayout>(R.id.toolStrip).addView(t)
  }

  private fun needVideo(): Boolean {
    if (uri == null) Toast.makeText(this, "Import a video first", Toast.LENGTH_SHORT).show()
    return uri != null
  }

  private fun togglePlay() {
    if (player.isPlaying) player.pause()
    else { if (player.currentPosition >= edit.te - 50 || player.currentPosition < edit.ts) player.seekTo(edit.ts); player.play() }
  }

  private fun openTool(t: Tool) {
    snap = edit; activeTool = t
    findViewById<TextView>(R.id.toolTitle).text = "${t.icon}  ${t.label}"
    findViewById<TextView>(R.id.toolValue).text = t.fmt(t.get(edit))
    ruler.configure(t.min, t.max, t.step, t.every, t.unitDp, t.get(edit))
    ruler.onChange = { v ->
      edit = t.set(edit, v)
      findViewById<TextView>(R.id.toolValue).text = t.fmt(v); scheduleApply()
    }
    toolPanel.visibility = View.VISIBLE
  }

  private fun closeTool() {
    toolPanel.visibility = View.GONE; activeTool = null
    if (edit != snap) { undo.addLast(snap); redo.clear() }
  }

  private fun commit(f: (Edit) -> Edit) {
    undo.addLast(edit); redo.clear(); edit = f(edit); applyEdit()
  }

  private fun scheduleApply() { h.removeCallbacks(applyRun); h.postDelayed(applyRun, 90) }

  private fun applyEdit() {
    if (uri == null) return
    player.setVideoEffects(videoEffects(edit, false))
    player.playbackParameters = PlaybackParameters(edit.speed)
    player.volume = minOf(edit.vol, 1f)
    timeline.setTrim(edit.ts, edit.te)
  }

  private fun videoEffects(e: Edit, forExport: Boolean): List<Effect> {
    val l = mutableListOf<Effect>()
    if (e.aspect > 0f && vw > 0 && vh > 0) {
      val cur = vw.toFloat() / vh
      if (cur > e.aspect) { val f = e.aspect / cur; l += Crop(-f, f, -1f, 1f) }
      else { val f = cur / e.aspect; l += Crop(-1f, 1f, -f, f) }
    }
    if (e.rot != 0f || e.flipH || e.flipV)
      l += ScaleAndRotateTransformation.Builder().setRotationDegrees(e.rot)
        .setScale(if (e.flipH) -1f else 1f, if (e.flipV) -1f else 1f).build()
    if (e.bright != 0f) l += Brightness(e.bright)
    if (e.contrast != 0f) l += Contrast(e.contrast)
    if (e.sat != 0f) l += HslAdjustment.Builder().adjustSaturation(e.sat).build()
    if (e.bw) l += RgbFilter.createGrayscaleFilter()
    if (e.text.isNotEmpty()) {
      val s = SpannableString(e.text)
      s.setSpan(ForegroundColorSpan(Color.WHITE), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
      s.setSpan(AbsoluteSizeSpan(64), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
      s.setSpan(BackgroundColorSpan(0x99000000.toInt()), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
      val st = OverlaySettings.Builder().setBackgroundFrameAnchor(0f, -0.6f).build()
      l += OverlayEffect(ImmutableList.of(TextOverlay.createStaticTextOverlay(s, st)))
    }
    if (forExport) {
      if (e.speed != 1f) l += SpeedChangeEffect(e.speed)
      if (vh > e.res) l += Presentation.createForHeight(e.res)
    }
    return l
  }

  private fun load(u: Uri) {
    uri = u; edit = Edit(); undo.clear(); redo.clear()
    findViewById<View>(R.id.emptyState).visibility = View.GONE
    timeline.thumbs = emptyList(); timeline.setDuration(0)
    player.setMediaItem(MediaItem.fromUri(u)); player.prepare(); player.play()
    Thread {
      try {
        val r = MediaMetadataRetriever(); r.setDataSource(this, u)
        val dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLong() ?: 0L
        val list = mutableListOf<Bitmap>()
        for (i in 0 until 10) {
          val f = r.getFrameAtTime(dur * 1000 * i / 10, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: continue
          list += Bitmap.createScaledBitmap(f, 112 * f.width / f.height, 112, true)
        }
        r.release()
        runOnUiThread { timeline.thumbs = list }
      } catch (_: Exception) { }
    }.start()
  }

  private fun export() {
    val u = uri ?: return
    if (exporting) return
    val e = edit
    val clip = MediaItem.ClippingConfiguration.Builder()
      .setStartPositionMs(e.ts).setEndPositionMs(e.te).build()
    val item = MediaItem.Builder().setUri(u).setClippingConfiguration(clip).build()
    val audio = mutableListOf<AudioProcessor>()
    if (e.speed != 1f) audio += SonicAudioProcessor().apply { setSpeed(e.speed) }
    if (e.vol != 1f) audio += ChannelMixingAudioProcessor().apply {
      for (ch in 1..2) putChannelMixingMatrix(ChannelMixingMatrix.create(ch, ch).scaleBy(e.vol))
    }
    val edited = EditedMediaItem.Builder(item).setEffects(Effects(audio, videoEffects(e, true))).build()
    val out = File(cacheDir, "OFEditor_${System.currentTimeMillis()}.mp4")
    exporting = true; player.pause(); exportBtn.text = "Exporting..."
    Transformer.Builder(this).addListener(object : Transformer.Listener {
      override fun onCompleted(composition: Composition, exportResult: ExportResult) {
        exporting = false; exportBtn.text = "⬇ Export"
        Toast.makeText(this@MainActivity, saveToGallery(out), Toast.LENGTH_LONG).show()
      }
      override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
        exporting = false; exportBtn.text = "⬇ Export"
        Toast.makeText(this@MainActivity, "Export failed: ${exportException.message}", Toast.LENGTH_LONG).show()
      }
    }).build().start(edited, out.absolutePath)
  }

  private fun saveToGallery(f: File): String {
    if (Build.VERSION.SDK_INT >= 29) {
      val v = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, f.name)
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/OF Editor")
      }
      val dest = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
      if (dest != null) {
        contentResolver.openOutputStream(dest)?.use { o -> f.inputStream().use { it.copyTo(o) } }
        f.delete(); return "Saved to Movies/OF Editor"
      }
    }
    val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir
    val dest = File(dir, f.name); f.copyTo(dest, true); f.delete()
    return "Saved: ${dest.absolutePath}"
  }

  private fun mmss(ms: Long) = "%02d:%02d".format(ms / 60000, ms / 1000 % 60)

  override fun onDestroy() {
    h.removeCallbacksAndMessages(null); player.release(); super.onDestroy()
  }
}
