package com.ofeditor.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs

/** Drag-to-scroll ruler (|1|1|1|1|) used like CapCut's sliders. */
class RulerView(c: Context, a: AttributeSet? = null) : View(c, a) {
  private val d = resources.displayMetrics.density
  private val p = Paint(Paint.ANTI_ALIAS_FLAG)
  private var min = -100f; private var max = 100f; private var step = 1f
  private var every = 10; private var unit = 8 * d
  private var raw = 0f; private var lastSnap = 0f; private var lastX = 0f
  private var vt: VelocityTracker? = null
  private var fling: ValueAnimator? = null
  var onChange: ((Float) -> Unit)? = null

  private fun snap(v: Float): Float = Math.round(v / step) * step

  fun configure(min: Float, max: Float, step: Float, every: Int, unitDp: Float, v: Float) {
    this.min = min; this.max = max; this.step = step; this.every = every; unit = unitDp * d
    setValue(v)
  }

  fun setValue(v: Float) { raw = v.coerceIn(min, max); lastSnap = snap(raw); invalidate() }

  private fun move(dv: Float) {
    raw = (raw + dv).coerceIn(min, max)
    val s = snap(raw)
    if (s != lastSnap) {
      lastSnap = s
      performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
      onChange?.invoke(s)
    }
    invalidate()
  }

  override fun onDraw(cv: Canvas) {
    val cx = width / 2f; val h = height.toFloat()
    val half = (cx / unit).toInt() + 2
    val base = Math.round(raw / step)
    p.textSize = 11 * d; p.textAlign = Paint.Align.CENTER; p.style = Paint.Style.FILL
    for (i in base - half..base + half) {
      val v = i * step
      if (v < min - 1e-3f || v > max + 1e-3f) continue
      val x = cx + (v - raw) / step * unit
      val big = i % every == 0
      p.color = if (big) 0xFFFFFFFF.toInt() else 0x88FFFFFF.toInt()
      p.strokeWidth = (if (big) 2.5f else 1.5f) * d
      cv.drawLine(x, h * 0.28f, x, h * (if (big) 0.62f else 0.52f), p)
      if (big) cv.drawText(if (step < 1f) "%.1f".format(v) else v.toInt().toString(), x, h * 0.92f, p)
    }
    p.color = 0xFFA855F7.toInt(); p.strokeWidth = 3.5f * d
    cv.drawLine(cx, h * 0.12f, cx, h * 0.68f, p)
  }

  override fun onTouchEvent(e: MotionEvent): Boolean {
    when (e.actionMasked) {
      MotionEvent.ACTION_DOWN -> {
        fling?.cancel(); lastX = e.x
        vt?.recycle(); vt = VelocityTracker.obtain(); vt?.addMovement(e)
        parent?.requestDisallowInterceptTouchEvent(true)
      }
      MotionEvent.ACTION_MOVE -> {
        vt?.addMovement(e)
        move(-(e.x - lastX) / unit * step); lastX = e.x
      }
      MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
        vt?.computeCurrentVelocity(1000)
        val vx = vt?.xVelocity ?: 0f
        vt?.recycle(); vt = null
        if (abs(vx) > 400f) {
          val dist = -vx * 0.25f / unit * step
          var prev = 0f
          fling = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 500; interpolator = DecelerateInterpolator()
            addUpdateListener { val f = it.animatedValue as Float; move((f - prev) * dist); prev = f }
            start()
          }
        }
      }
    }
    return true
  }
}
